package com.es2.multipleconditions;

public class PersonCannotDriveException extends Exception {

}
